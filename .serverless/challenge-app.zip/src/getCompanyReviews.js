"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const database_1 = require("./db/database");
const handler = async (event) => {
    try {
        const companyId = event.pathParameters?.companyId;
        if (!companyId)
            return {
                statusCode: 400,
                body: JSON.stringify({ message: "Missing companyId" }),
            };
        const company = await database_1.prismaDb.company.findUnique({
            where: {
                id: Number(companyId),
            },
            include: {
                reviews: {
                    include: {
                        reviewer: true,
                    },
                    orderBy: {
                        publishedAt: "desc",
                    },
                },
            },
        });
        await database_1.prismaDb.$disconnect();
        return {
            statusCode: 200,
            body: JSON.stringify(company),
        };
    }
    catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Error to get company reviews",
                error: JSON.stringify(error, null, 2),
                env: process.env.DATABASE_URL,
            }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=getCompanyReviews.js.map