"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.apifyFunctions = void 0;
const apify_client_1 = require("apify-client");
const constants_1 = require("./constants");
const schemas_1 = require("../../utils/schemas");
const client = new apify_client_1.ApifyClient({
    token: process.env.APIFY_ACCESS_TOKEN,
});
async function getCountReviewsBody() {
    const getCountReviewsBody = {
        deeperCityScrape: false,
        includeWebResults: false,
        language: "pt-BR",
        maxCrawledPlacesPerSearch: 1,
        maxImages: 0,
        maxReviews: 0,
        onlyDataFromSearchPage: true,
        scrapeDirectories: false,
        scrapeResponseFromOwnerText: false,
        scrapeReviewId: false,
        scrapeReviewUrl: false,
        scrapeReviewerId: false,
        scrapeReviewerName: false,
        scrapeReviewerUrl: false,
        skipClosedPlaces: false,
        startUrls: [
            ...constants_1.GoogleMapsCompanies.map((company) => ({
                url: company.url,
            })),
        ],
    };
    const run = await client.actor("nwua9Gu5YrADL7ZDj").call(getCountReviewsBody);
    const { items } = await client.dataset(run.defaultDatasetId).listItems();
    const validItems = schemas_1.minimalScrapeSchema.safeParse(items);
    if (!validItems.success) {
        return {
            error: validItems.error,
        };
    }
    return { data: validItems.data };
}
async function getReviews(props) {
    const { searchReviewCount, companyUrl } = props;
    const getReviewsBody = {
        deeperCityScrape: false,
        includeWebResults: true,
        language: "pt-BR",
        maxCrawledPlacesPerSearch: 1,
        maxImages: 0,
        reviewsSort: "newest",
        maxReviews: searchReviewCount,
        onlyDataFromSearchPage: false,
        scrapeDirectories: false,
        scrapeResponseFromOwnerText: true,
        scrapeReviewId: true,
        scrapeReviewUrl: true,
        scrapeReviewerId: true,
        scrapeReviewerName: true,
        scrapeReviewerUrl: true,
        skipClosedPlaces: false,
        startUrls: [
            {
                url: companyUrl,
            },
        ],
    };
    const reviewsRun = await client
        .actor("nwua9Gu5YrADL7ZDj")
        .call(getReviewsBody);
    const reviews = await client.dataset(reviewsRun.defaultDatasetId).listItems();
    const validReviews = schemas_1.scrapeSchema.safeParse(reviews.items);
    if (!validReviews.success) {
        return {
            error: validReviews.error,
        };
    }
    return { data: validReviews.data };
}
exports.apifyFunctions = Object.freeze({
    getCountReviewsBody,
    getReviews,
});
//# sourceMappingURL=api.js.map