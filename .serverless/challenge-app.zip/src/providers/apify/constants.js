"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GoogleMapsCompanies = void 0;
exports.GoogleMapsCompanies = [
    {
        url: "https://maps.app.goo.gl/eW4pSUbBSoqShZMM9",
        title: "Nema - Visconde de Pirajá | Padaria de Fermentação Natural",
    },
    {
        url: "https://maps.app.goo.gl/ygVaxUJHR6zZcWqS9",
        title: "Nema - Botafogo | Padaria de Fermentação Natural",
    },
    {
        url: "https://maps.app.goo.gl/KUbFispshk2vE55E7",
        title: "Nema Padaria - Leblon | Padaria de Fermentação Natural",
    },
];
//# sourceMappingURL=constants.js.map