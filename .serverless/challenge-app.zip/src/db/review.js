"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reviewPrismaQuery = void 0;
const database_1 = require("./database");
async function findReview(props) {
    let reviewExists;
    const { likesCount, placeId, publishedAtDate, reviewUrl, stars, text, reviewId, textTranslated, } = props;
    if (!reviewId) {
        reviewExists = await database_1.prismaDb.review.findFirst({
            where: {
                content: textTranslated ?? text,
                stars: stars,
                likesCount: likesCount,
                reviewUrl: reviewUrl,
                publishedAt: publishedAtDate,
                company: {
                    placeId,
                },
            },
        });
    }
    else {
        reviewExists = await database_1.prismaDb.review.findUnique({
            where: {
                externalReviewId: reviewId,
            },
        });
    }
    return reviewExists;
}
exports.reviewPrismaQuery = Object.freeze({ findReview });
//# sourceMappingURL=review.js.map