"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.companyPrismaQuery = void 0;
const database_1 = require("./database");
async function findCompanyByPlaceId(placeId) {
    return await database_1.prismaDb.company.findUnique({
        where: {
            placeId,
        },
        include: {
            reviews: {
                orderBy: {
                    publishedAt: "desc",
                },
            },
        },
    });
}
async function createCompany(props) {
    return await database_1.prismaDb.company.create({
        data: props,
    });
}
async function updateCompany(props) {
    const { placeId, ...rest } = props;
    return await database_1.prismaDb.company.update({
        where: {
            placeId: props.placeId,
        },
        data: rest,
    });
}
exports.companyPrismaQuery = Object.freeze({
    findCompanyByPlaceId,
    createCompany,
    updateCompany,
});
//# sourceMappingURL=company.js.map